# Nội dung trang cửa hàng (dán vào Play Console)

**Tên ứng dụng (≤30 ký tự):** Lịch vạn niên

**Mô tả ngắn (≤80 ký tự):** Lịch âm dương, tiết khí, ngày lễ Việt Nam, ghi chú và nhắc việc.

**Mô tả đầy đủ:**
Lịch vạn niên giúp bạn xem nhanh ngày dương, ngày âm, can chi, tiết khí và các ngày lễ của Việt Nam ngay trên điện thoại.

• Xem lịch dương và âm lịch trong cùng một màn hình
• Hiển thị can chi, năm âm lịch, tiết khí và các ngày lễ
• Ghi chú cho từng ngày, thêm nhắc việc và nhận thông báo đúng ngày
• Giao diện sáng/tối, đổi ảnh nền theo ý thích
• Chạy ngoại tuyến, không cần tài khoản, không quảng cáo
• Dữ liệu chỉ lưu trên máy của bạn

**Danh mục:** Công cụ (hoặc Năng suất) · Loại: Ứng dụng · Miễn phí
**Ngôn ngữ mặc định:** Tiếng Việt
**Đối tượng:** 18+ hoặc "mọi lứa tuổi" tuỳ bạn chọn; không nhắm riêng trẻ em
**Xếp hạng nội dung:** trả lời "Không" cho mọi câu về bạo lực, tình dục, cờ bạc, ma tuý, UGC

## An toàn dữ liệu (Data safety)
- Ứng dụng có thu thập/chia sẻ dữ liệu người dùng? → **Không**
- Dữ liệu mã hoá khi truyền? → không áp dụng (không truyền dữ liệu)
- Cho phép yêu cầu xoá dữ liệu? → dữ liệu chỉ ở trên máy; gỡ app là xoá hết
- Không có quảng cáo: **Có khai báo "Không chứa quảng cáo"**
- Quyền nhạy cảm: chỉ POST_NOTIFICATIONS

## Ảnh
- icon-512.png (512×512) · feature-graphic-1024x500.png · screenshot-1..3.png (1080×2160)
- Cần tối thiểu 2 ảnh chụp màn hình điện thoại.

## Việc phải làm ở chỗ khác
- Điền địa chỉ trang `privacy.html` đã đưa lên mạng vào mục "Chính sách quyền riêng tư".
- Sửa [TÊN NHÀ PHÁT TRIỂN] và [EMAIL LIÊN HỆ] trong `www/privacy.html`.
