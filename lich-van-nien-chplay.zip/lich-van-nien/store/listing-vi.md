# Nội dung trang cửa hàng (dán vào Play Console)

**Tên ứng dụng (≤30 ký tự):** Lịch vạn niên

**Mô tả ngắn (≤80 ký tự):** Lịch âm dương, giờ hoàng đạo, tiết khí, ngày lễ, ghi chú và nhắc việc.

**Mô tả đầy đủ:**
Lịch vạn niên giúp bạn xem nhanh ngày dương, ngày âm, can chi, tiết khí, giờ hoàng đạo và các ngày lễ của Việt Nam ngay trên điện thoại. Giao diện gọn, dễ đọc, chạy hoàn toàn ngoại tuyến.

• Lịch dương và âm lịch trong cùng một màn hình, mùng một và rằm được đánh dấu
• Trang "Chi tiết ngày": can chi ngày, tháng, năm; ngày Hoàng đạo hay Hắc đạo; giờ hoàng đạo; tiết khí
• Vuốt trái/phải để chuyển ngày, bấm tháng để nhảy nhanh tới tháng khác
• Ngày lễ dương lịch và âm lịch của Việt Nam
• Ghi chú cho từng ngày, lặp hằng năm theo dương lịch hoặc âm lịch (rất tiện cho ngày giỗ, sinh nhật âm lịch)
• Nhắc việc và thông báo đúng ngày
• Mỗi tháng một phong cảnh, hoặc dùng ảnh của riêng bạn làm ảnh nền
• Giao diện sáng/tối, cỡ chữ lớn dễ đọc
• Không cần tài khoản, không quảng cáo, dữ liệu chỉ lưu trên máy của bạn

Lưu ý: thông tin ngày/giờ hoàng đạo, hắc đạo mang tính tham khảo theo văn hoá truyền thống.

**Danh mục:** Công cụ (hoặc Năng suất) · Loại: Ứng dụng · Miễn phí
**Ngôn ngữ mặc định:** Tiếng Việt
**Đối tượng:** 18+ hoặc "mọi lứa tuổi" tuỳ bạn chọn; không nhắm riêng trẻ em
**Xếp hạng nội dung:** trả lời "Không" cho mọi câu về bạo lực, tình dục, cờ bạc, ma tuý, UGC

## An toàn dữ liệu (Data safety)
- Ứng dụng có thu thập/chia sẻ dữ liệu người dùng? → **Không**
- Dữ liệu mã hoá khi truyền? → không áp dụng (không truyền dữ liệu)
- Cho phép yêu cầu xoá dữ liệu? → dữ liệu chỉ ở trên máy; gỡ app là xoá hết
- Không có quảng cáo: **Có khai báo "Không chứa quảng cáo"**
- Quyền nhạy cảm: chỉ POST_NOTIFICATIONS

## Ảnh
- icon-512.png (512×512) · feature-graphic-1024x500.png · screenshot-1..5.png (1080×2160)
- Cần tối thiểu 2 ảnh chụp màn hình điện thoại; bộ này có 5 ảnh theo thứ tự: màn hình chính · phong cảnh theo tháng · chi tiết ngày · ghi chú · giao diện tối.
- Ảnh chụp dùng dữ liệu mẫu (ghi chú giả định), không có thông tin cá nhân.

## Việc phải làm ở chỗ khác
- Điền địa chỉ trang `privacy.html` đã đưa lên mạng vào mục "Chính sách quyền riêng tư".
- Sửa [TÊN NHÀ PHÁT TRIỂN] và [EMAIL LIÊN HỆ] trong `www/privacy.html`.
