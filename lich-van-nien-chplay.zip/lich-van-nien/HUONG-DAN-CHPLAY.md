# Đưa Lịch vạn niên lên CH Play

Đã chuẩn hoá: Capacitor 8 (nhắm Android 16 / API 36 theo yêu cầu Google Play từ 31/8/2026), thư mục `www/`, icon thích ứng, icon thông báo, trang quyền riêng tư, ảnh cửa hàng, quy trình build tự động.

## A. Chuẩn bị (một lần)
1. Đăng ký **Google Play Console** (phí 25 USD, cần xác minh danh tính).
2. Đưa thư mục `www/` lên Netlify như cũ; địa chỉ `.../privacy.html` là link chính sách quyền riêng tư. Sửa tên và email trong file đó trước.
3. Tạo khoá ký (chạy trên máy có Java, giữ file và mật khẩu cẩn thận):
   `keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000`
   Trong Play Console bật **Play App Signing** (mặc định) để Google giữ khoá chính.

## B0. Thử trước trên điện thoại (không cần khoá ký)
Tab Actions → "Build APK cai thu" → Run workflow → tải `app-debug.apk` ở Artifacts, cài lên máy để kiểm tra. File này chỉ để thử, không đưa lên CH Play.

## B. Tạo file .aab (không cần cài Android Studio)
1. Tạo kho GitHub riêng tư, tải toàn bộ thư mục này lên.
2. Settings → Secrets → Actions, thêm: `KEYSTORE_BASE64` (kết quả `base64 -w0 upload.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (= upload).
3. Tab Actions → "Build AAB cho CH Play" → Run workflow → tải file `lich-van-nien.aab` ở mục Artifacts.
4. Mỗi lần cập nhật: tăng biến `VERSION_CODE` (Settings → Variables) lên 2, 3... và `VERSION_NAME`.

## C. Đăng lên Play Console
1. Tạo ứng dụng → điền theo `store/listing-vi.md`, tải ảnh trong `store/`.
2. Điền: Chính sách quyền riêng tư, An toàn dữ liệu, Xếp hạng nội dung, Đối tượng, Khai báo quảng cáo (không có).
3. Tài khoản cá nhân mới thường phải chạy **thử nghiệm kín với tối thiểu 12 người trong 14 ngày** trước khi lên bản chính thức; hãy kiểm tra yêu cầu hiện hành trong Play Console.
4. Tải `.aab` lên kênh thử nghiệm → gửi duyệt.

## Chưa kiểm chứng
- Chưa build được .aab trong môi trường này (không có Android SDK / mạng), nên workflow chưa chạy thử. Lần chạy đầu có thể cần chỉnh nhỏ.
- Phông chữ vẫn tải từ Google Fonts; mất mạng lần đầu sẽ dùng phông hệ thống.
- Nhắc việc đặt lúc 8:00 sáng, không dùng báo thức chính xác, nên không cần xin quyền SCHEDULE_EXACT_ALARM (tránh bị Google hỏi lý do). Giờ nhắc có thể lệch vài phút.
- Nhớ thử trên điện thoại thật: thông báo, nút quay lại, xoay màn hình.
