/* Service worker: dùng được khi không có mạng. Đổi số phiên bản để buộc cập nhật. */
const VERSION = "lvn-v43";
const SHELL = ["./", "index.html", "manifest.webmanifest", "icon-192.png", "icon-512.png", "icon-maskable-512.png", "apple-touch-icon.png"];
const FONT_HOSTS = ["fonts.googleapis.com", "fonts.gstatic.com"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  // Phông chữ: dùng bản đã lưu, đồng thời cập nhật ngầm.
  if (FONT_HOSTS.includes(url.hostname)) {
    e.respondWith(
      caches.open(VERSION).then((cache) =>
        cache.match(req).then((hit) => {
          const net = fetch(req).then((res) => { if (res && (res.ok || res.type === "opaque")) cache.put(req, res.clone()); return res; }).catch(() => hit);
          return hit || net;
        })
      )
    );
    return;
  }

  if (url.origin !== location.origin) return;

  // Trang: ưu tiên mạng để nhận bản mới, mất mạng thì dùng bản đã lưu.
  if (req.mode === "navigate") {
    e.respondWith(
      fetch(req)
        .then((res) => { const copy = res.clone(); caches.open(VERSION).then((c) => c.put("index.html", copy)); return res; })
        .catch(() => caches.match("index.html").then((r) => r || caches.match("./")))
    );
    return;
  }

  // Tệp tĩnh còn lại: bản đã lưu trước.
  e.respondWith(caches.match(req).then((hit) => hit || fetch(req).then((res) => {
    if (res.ok) { const copy = res.clone(); caches.open(VERSION).then((c) => c.put(req, copy)); }
    return res;
  })));
});

// Nhắc nền (nếu trình duyệt cho phép): đọc danh sách ngày đã lưu và báo vào đúng ngày.
function idbGet(k){return new Promise((ok)=>{const q=indexedDB.open("lvn",1);q.onupgradeneeded=()=>q.result.createObjectStore("kv");q.onerror=()=>ok();q.onsuccess=()=>{const r=q.result.transaction("kv").objectStore("kv").get(k);r.onsuccess=()=>ok(r.result);r.onerror=()=>ok()}})}
function idbPut(k,v){return new Promise((ok)=>{const q=indexedDB.open("lvn",1);q.onupgradeneeded=()=>q.result.createObjectStore("kv");q.onerror=()=>ok();q.onsuccess=()=>{const tx=q.result.transaction("kv","readwrite");tx.objectStore("kv").put(v,k);tx.oncomplete=()=>ok()}})}
self.addEventListener("periodicsync",(e)=>{
  if(e.tag!=="lvn-due")return;
  e.waitUntil((async()=>{
    const t=new Date(),key=t.getFullYear()+"-"+String(t.getMonth()+1).padStart(2,"0")+"-"+String(t.getDate()).padStart(2,"0");
    const due=await idbGet("due"),last=await idbGet("last");
    if(!due||!due[key]||last===key)return;
    await idbPut("last",key);
    await self.registration.showNotification("Lịch vạn niên",{body:"Hôm nay: "+due[key].join(", "),icon:"icon-192.png",badge:"icon-192.png",tag:"lvn-due"});
  })());
});
self.addEventListener("notificationclick",(e)=>{
  e.notification.close();
  e.waitUntil(self.clients.matchAll({type:"window"}).then((cs)=>cs.length?cs[0].focus():self.clients.openWindow("./")));
});
